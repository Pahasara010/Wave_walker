import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css'; // If you have CSS file

const root = createRoot.getElementById('root'));
createRoot(<App />);