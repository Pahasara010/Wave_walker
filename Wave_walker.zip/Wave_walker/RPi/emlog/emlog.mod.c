#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xe3ec2f2b, "alloc_chrdev_region" },
	{ 0x9d8eb028, "cdev_alloc" },
	{ 0xe72ec58e, "cdev_add" },
	{ 0x122c3a7e, "_printk" },
	{ 0x1b58158e, "class_create" },
	{ 0xc3ddd38, "device_create" },
	{ 0xe39f8219, "device_destroy" },
	{ 0xf4e1b5d, "class_destroy" },
	{ 0x9875d727, "cdev_del" },
	{ 0x6091b333, "unregister_chrdev_region" },
	{ 0x999e8297, "vfree" },
	{ 0x52c5c991, "__kmalloc_noprof" },
	{ 0xdcb764ad, "memset" },
	{ 0xe68efe41, "_raw_write_lock" },
	{ 0x4829a47e, "memcpy" },
	{ 0x40235c98, "_raw_write_unlock" },
	{ 0x37a0cba, "kfree" },
	{ 0xe2964344, "__wake_up" },
	{ 0x12a4e128, "__arch_copy_from_user" },
	{ 0x86db0705, "module_put" },
	{ 0x5f5d260f, "try_module_get" },
	{ 0x6568f461, "kmalloc_caches" },
	{ 0xb104dc7c, "__kmalloc_cache_noprof" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0x1b2fa1a9, "vmalloc_noprof" },
	{ 0xfe8c61f0, "_raw_read_lock" },
	{ 0xdd4d55b6, "_raw_read_unlock" },
	{ 0x6cbbfc54, "__arch_copy_to_user" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0x1000e51, "schedule" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0x92540fbf, "finish_wait" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0xc963e375, "noop_llseek" },
	{ 0xa8fa7cc2, "param_ops_int" },
	{ 0x1f7d8c49, "param_ops_bool" },
	{ 0x47e64c59, "module_layout" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "71FCCA2238118864B0B89C9");
