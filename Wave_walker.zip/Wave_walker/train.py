#!/usr/bin/env python3

import sys
import pathlib  # For handling file paths
import logging  # For logging system events and errors
import contextlib  # For redirecting stdout to suppress model fitting output
import io  # For in-memory string buffer
from tqdm import tqdm  # For progress bars
from sklearn.model_selection import train_test_split, KFold  # For data splitting and cross-validation
from sklearn.metrics import confusion_matrix, accuracy_score, classification_report  # For evaluation metrics
import matplotlib  # For plotting
matplotlib.use('Agg')  # Force non-interactive backend for server-side plotting
import matplotlib.pyplot as plt  # For creating plots
import numpy as np  # For numerical operations
from HAR.transformers import ActivityRecognitionPipeline  # Custom module for the ROCKET model
from HAR.io import load_dataset  # Custom module for loading CSI datasets

# Configure logging to display INFO level messages and above
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CSIModelTrainer:
    ACTIVITY_LABELS = ["walking", "running", "jumping", "idle", "empty"]  # List of activity classes
    NUM_CLASSES = len(ACTIVITY_LABELS)  # Number of activity classes (5)
    NUM_KERNELS = 500  # Number of kernels for the ROCKET model

    def __init__(self, main_dataset_path, holdout_dataset_path, train_fraction, output_dir) -> None:
        """Initialize the CSIModelTrainer for training an HAR model on CSI data.
        
        Args:
            main_dataset_path (str): Path to the main dataset for training and validation.
            holdout_dataset_path (str): Path to the holdout dataset for final testing.
            train_fraction (float): Proportion of main dataset to use for training (0 to 1).
            output_dir (str): Directory to save the trained model and plots.
        """
        self.main_dataset_path = main_dataset_path
        self.holdout_dataset_path = holdout_dataset_path
        self.train_fraction = train_fraction
        self.output_dir = pathlib.Path(output_dir)  # Convert to Path object
        self.output_dir.mkdir(parents=True, exist_ok=True)  # Create output directory if it doesn't exist

        # Initialize the ROCKET model pipeline with specified parameters
        self.pipeline = ActivityRecognitionPipeline(
            num_classes=self.NUM_CLASSES,
            num_kernels=self.NUM_KERNELS,
            batch_size=64,
            normalize=True,
            show_progress=False,  # Disable internal progress bars for cleaner output
        )

    def run(self):
        """Execute the full training pipeline, including data loading, training, evaluation, and saving."""
        # Define stages and their relative weights for the progress bar
        stages = [
            ("Loading and splitting main dataset", 1),  # Weight for data loading
            ("Training the model and accuracy curve", 6),  # Increased weight for cross-validation
            ("Evaluating on validation set", 2),  # Weight for validation evaluation
            ("Loading holdout dataset", 1),  # Weight for holdout data loading
            ("Evaluating on holdout set", 2),  # Weight for holdout evaluation
            ("Saving model and plots", 2),  # Weight for saving artifacts
        ]
        total_units = sum(weight for _, weight in stages)  # Total progress units

        # Create a single progress bar for the entire training session
        with tqdm(total=total_units, desc="Training Session", unit="step") as pbar:
            # Stage 1: Load and prepare main dataset
            pbar.set_description("Loading and splitting main dataset")
            X, y, _, _, input_shape = load_dataset(self.main_dataset_path)  # Load dataset
            X = X.reshape(X.shape[0], *input_shape)  # Reshape to match model input
            logger.info(f"Dataset loaded: {X.shape[0]} samples with shape {X.shape[1:]}")
            pbar.update(stages[0][1])

            # Stage 2: Train the model and generate accuracy curve
            pbar.set_description("Training the model and accuracy curve")
            accuracies = self._train_model_with_curve(X, y)  # Perform cross-validation
            self._plot_accuracy_curve(accuracies)  # Plot the accuracy curve
            pbar.update(stages[1][1])

            # Stage 3: Evaluate on validation set (final split)
            pbar.set_description("Evaluating on validation set")
            X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=self.train_fraction, stratify=y)
            with contextlib.redirect_stdout(io.StringIO()):  # Suppress model fitting output
                self.pipeline.fit(X_train, y_train)  # Train on the final training split
            val_predictions = self.pipeline.predict(X_test)  # Predict on validation set
            self._plot_confusion_matrix(y_test, val_predictions, "validation_confusion_matrix.png")  # Plot confusion matrix
            logger.info(f"Validation Accuracy: {accuracy_score(y_test, val_predictions)*100:.2f}%")
            logger.info("Validation Confusion Matrix:")
            logger.info(confusion_matrix(y_test, val_predictions))
            logger.info("Validation Classification Report:")
            logger.info(classification_report(y_test, val_predictions, target_names=self.ACTIVITY_LABELS))
            pbar.update(stages[2][1])

            # Stage 4: Load holdout dataset
            pbar.set_description("Loading holdout dataset")
            X_holdout, _, y_holdout, _ = self._prepare_data_splits(self.holdout_dataset_path, None)  # Load without splitting
            pbar.update(stages[3][1])

            # Stage 5: Evaluate on holdout set
            pbar.set_description("Evaluating on holdout set")
            holdout_predictions = self.pipeline.predict(X_holdout)  # Predict on holdout set
            self._plot_confusion_matrix(y_holdout, holdout_predictions, "holdout_confusion_matrix.png")  # Plot confusion matrix
            logger.info(f"Holdout Accuracy: {accuracy_score(y_holdout, holdout_predictions)*100:.2f}%")
            logger.info("Holdout Confusion Matrix:")
            logger.info(confusion_matrix(y_holdout, holdout_predictions))
            logger.info("Holdout Classification Report:")
            logger.info(classification_report(y_holdout, holdout_predictions, target_names=self.ACTIVITY_LABELS))
            pbar.update(stages[4][1])

            # Stage 6: Save the model and plots
            pbar.set_description("Saving model and plots")
            self.pipeline.save(self.output_dir)  # Save the trained model
            plt.savefig(self.output_dir / "accuracy_curve.png")  # Save the accuracy curve plot
            logger.info(f"Trained model and plots saved to: {self.output_dir}")
            pbar.update(stages[5][1])

    def _prepare_data_splits(self, dataset_path, train_fraction):
        """Prepare data splits from the dataset, optionally splitting into train and test.
        
        Args:
            dataset_path (str): Path to the dataset.
            train_fraction (float or None): Proportion to use for training, or None for no split.
        
        Returns:
            tuple: X, X_test, y, y_test (all None if no split).
        """
        X, y, _, _, input_shape = load_dataset(dataset_path)
        X = X.reshape(X.shape[0], *input_shape)
        if train_fraction is None:
            return X, None, y, None
        return train_test_split(X, y, train_size=train_fraction, stratify=y)

    def _train_model_with_curve(self, X, y):
        """Train the model using k-fold cross-validation and return accuracies.
        
        Args:
            X (np.ndarray): Input features.
            y (np.ndarray): Target labels.
        
        Returns:
            list: List of accuracy scores for each fold.
        """
        n_splits = 5  # Number of cross-validation folds
        kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)  # Configure KFold
        accuracies = []

        for train_idx, val_idx in kf.split(X):
            X_train, X_val = X[train_idx], X[val_idx]
            y_train, y_val = y[train_idx], y[val_idx]
            with contextlib.redirect_stdout(io.StringIO()):  # Suppress output
                self.pipeline.fit(X_train, y_train)
            val_predictions = self.pipeline.predict(X_val)
            accuracy = accuracy_score(y_val, val_predictions)
            accuracies.append(accuracy)
            logger.info(f"Cross-validation fold accuracy: {accuracy*100:.2f}%")

        return accuracies

    def _plot_accuracy_curve(self, accuracies):
        """Plot the accuracy curve across cross-validation folds.
        
        Args:
            accuracies (list): List of accuracy scores.
        """
        plt.figure(figsize=(8, 6))  # Set figure size
        plt.plot(range(1, len(accuracies) + 1), accuracies, marker='o', linestyle='-', color='b')  # Plot accuracy
        plt.title('Accuracy Curve Across Cross-Validation Folds')
        plt.xlabel('Fold')
        plt.ylabel('Accuracy')
        plt.grid(True)  # Add grid for readability
        plt.ylim(0, 1)  # Set y-axis limits
        plt.savefig(self.output_dir / "accuracy_curve.png")  # Save the plot
        plt.close()  # Close the figure to free memory

    def _plot_confusion_matrix(self, y_true, y_pred, filename):
        """Plot and save a confusion matrix for the given predictions.
        
        Args:
            y_true (np.ndarray): True labels.
            y_pred (np.ndarray): Predicted labels.
            filename (str): Name of the file to save the plot.
        """
        try:
            cm = confusion_matrix(y_true, y_pred)  # Compute confusion matrix
            logger.info(f"Generating confusion matrix with data: {cm}")  # Debug log
            plt.figure(figsize=(8, 6))  # Set figure size
            plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)  # Display matrix
            plt.title(f'Confusion Matrix - {filename.split(".")[0]}')
            plt.colorbar()  # Add colorbar
            tick_marks = np.arange(len(self.ACTIVITY_LABELS))
            plt.xticks(tick_marks, self.ACTIVITY_LABELS, rotation=45)  # Set x-axis labels
            plt.yticks(tick_marks, self.ACTIVITY_LABELS)  # Set y-axis labels
            # Add text annotations
            thresh = cm.max() / 2.
            for i, j in np.ndindex(cm.shape):
                plt.text(j, i, f'{cm[i, j]}', horizontalalignment="center",
                         color="white" if cm[i, j] > thresh else "black", fontsize=8)
            plt.xlabel('Predicted Label')
            plt.ylabel('True Label')
            plt.tight_layout()  # Adjust layout to fit annotations
            plt.savefig(self.output_dir / filename)  # Save the plot
            logger.info(f"Confusion matrix saved to {self.output_dir / filename}")
            plt.close()  # Close the figure
        except Exception as e:
            logger.error(f"Failed to plot confusion matrix: {e}")

def main(args):
    """Main function to initialize and run the trainer with provided arguments.
    
    Args:
        args: Command-line arguments parsed by argparse.
    """
    trainer = CSIModelTrainer(args.main_set, args.hold_set, args.train_size, args.dump)
    trainer.run()

if __name__ == "__main__":
    """Entry point for the script, parsing command-line arguments and starting the training."""
    import argparse

    def valid_fraction(value):
        """Validate that the input is a fraction between 0 and 1.
        
        Args:
            value (str): Input value to validate.
        
        Returns:
            float: Validated fraction.
        
        Raises:
            argparse.ArgumentTypeError: If the value is not between 0 and 1.
        """
        float_value = float(value)
        if float_value < 0 or float_value > 1:
            raise argparse.ArgumentTypeError(f"{value} is not between 0 and 1")
        return float_value

    # Define command-line arguments
    parser = argparse.ArgumentParser(description="Train HAR model using CSI data")
    parser.add_argument("--main-set", help="Path to main dataset for training and initial testing", type=str, required=True)
    parser.add_argument("--hold-set", help="Path to holdout dataset for final testing", type=str, required=True)
    parser.add_argument("--train-size", help="Proportion of main set to use for training", type=valid_fraction, default=0.8)
    parser.add_argument("--dump", help="Directory to save trained model parameters", type=str, required=True)

    args = parser.parse_args()

    try:
        main(args)  # Run the main function with parsed arguments
    except KeyboardInterrupt:
        logger.error("Training interrupted by user.")  # Log interruption
