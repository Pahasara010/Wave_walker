#!/usr/bin/env python3

import sys
import pathlib
import warnings
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))  # Add the script's parent directory to the system path for importing custom modules

import asyncio  # For asynchronous WebSocket handling
import json  # For serializing prediction payloads
import logging  # For logging system events and errors
from datetime import datetime, timedelta  # For handling timestamps and time windows
from typing import Optional, List  # For type hints
from io import StringIO  # For in-memory string buffer to parse CSV data
import time  # For delays during FIFO reconnection attempts
import numpy as np  # For numerical operations on CSI data
import pandas as pd  # For parsing and processing CSV-like CSI data
import torch  # For tensor operations in the ROCKET model
import websockets  # For WebSocket server to broadcast predictions
import pyrebase  # For Firebase integration (logging and system state)
import smtplib  # For sending email alerts
from email.mime.text import MIMEText  # For constructing email messages

from HAR.transformers import CSIAmplitudeMinMaxScaler, ActivityRecognitionPipeline  # Custom modules for CSI scaling and activity recognition
from HAR.constants import CSI_COL_NAMES, NULL_SUBCARRIERS  # Constants for CSI column names and null subcarriers to remove

# Configure logging to display INFO level messages and above
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CSIHAR:
    def __init__(self, config):
        """Initialize the CSIHAR class for real-time HAR using CSI data.
        
        Args:
            config (dict): Configuration dictionary containing FIFO path, model path, class labels, etc.
        """
        self.config = config
        self.fifo_path = config["fifo_path"]  # Path to the FIFO buffer for reading CSI data
        self.expected_samples = config["expected_samples"]  # Number of samples expected per prediction
        self.input_shape = tuple(config["input_shape"])  # Expected shape of CSI data (height, width)
        self.class_labels = config["class_labels"]  # List of activity labels (e.g., empty, idle, jump, run, walk)
        self.num_classes = len(self.class_labels)  # Number of activity classes

        # Initialize the scaler for normalizing CSI amplitude data
        self.scaler = CSIAmplitudeMinMaxScaler()
        # Load the pre-trained ROCKET model for activity recognition
        self.recognizer = ActivityRecognitionPipeline(
            num_classes=self.num_classes,
            num_kernels=config["num_kernels"],
            batch_size=config["batch_size"],
            normalize=True,
            show_progress=False,
        ).load(pathlib.Path(config["model_path"]))

        # Initialize the output payload structure for predictions
        self.output_payload = {
            "timestamp": None,  # Timestamp of the prediction
            "hypothesis": None,  # Predicted activity and area (e.g., room1_jump)
            "classnames": self.class_labels,  # List of class labels
            "rx_sources": None  # List of areas contributing to the prediction
        }

        self.fifo = None  # File object for reading from FIFO
        self.ensure_fifo_open()  # Ensure the FIFO is opened for reading

        # Initialize a sliding window for aggregating predictions over 3 seconds
        self.window_predictions = []
        self.last_output_time = datetime.utcnow()
        self.window_duration = timedelta(seconds=3)

        # Initialize Firebase for logging activity events
        self.firebase = pyrebase.initialize_app(config["firebase_config"])
        self.db = self.firebase.database()
        self.db.child("system").set({"armed": True})  # Set system armed status to True
        logger.info("[Firebase] Initialized and set system/armed: true")

        # Store email credentials for sending alerts
        self.email_address = config["email_address"]
        self.email_password = config["email_password"]

    def ensure_fifo_open(self):
        """Ensure the FIFO file is open for reading, retrying if not found."""
        while self.fifo is None:
            try:
                self.fifo = open(self.fifo_path, 'r')  # Open FIFO in read mode
                logger.info(f"[FIFO] Connected to {self.fifo_path}")
            except FileNotFoundError:
                logger.warning(f"[FIFO] {self.fifo_path} not found. Retrying in 1 second...")
                time.sleep(1)  # Wait 1 second before retrying

    def send_alert(self, activity):
        """Send an email alert for a detected suspicious activity.
        
        Args:
            activity (str): The detected activity (e.g., room1_jump).
        """
        # Construct email message
        msg = MIMEText(f"Alert: Suspicious {activity} detected at {datetime.utcnow()}")
        msg['Subject'] = 'Home Security Alert'
        msg['From'] = self.email_address
        msg['To'] = self.config["alert_email"]
        try:
            # Connect to Gmail SMTP server and send the email
            with smtplib.SMTP('smtp.gmail.com', 587) as server:
                server.starttls()  # Enable TLS
                server.login(self.email_address, self.email_password)  # Authenticate
                server.send_message(msg)  # Send the email
            logger.info(f"[Alert] Sent email for {activity}")
        except Exception as e:
            logger.error(f"[Alert Error] {e}")

    def get_area_from_line(self) -> str:
        """Extract the area (e.g., room name) from the FIFO data line.
        
        Returns:
            str: The area name (e.g., 'room1') or 'unknown' if not found.
        """
        try:
            self.fifo.seek(0)  # Reset FIFO read position
            line = self.fifo.readline()  # Read the first line
            if line.startswith("room"):
                return line.split(":")[0].strip()  # Extract the room name before the colon
            return "unknown"
        except Exception:
            return "unknown"

    def make_prediction(self) -> Optional[str]:
        """Make a prediction on the next CSI sample and aggregate over a 3-second window.
        
        Returns:
            Optional[str]: JSON string of the prediction payload if ready, None otherwise.
        """
        try:
            # Retrieve and preprocess the next CSI sample
            csi_sample = self.get_next_sample()
            if csi_sample is None:
                logger.warning("[Prediction] No sample retrieved.")
                return None

            # Adjust the CSI sample shape to match the expected input shape
            target_h, target_w = self.input_shape
            h, w = csi_sample.shape

            # Pad or truncate height (subcarriers)
            if h < target_h:
                csi_sample = np.pad(csi_sample, ((0, target_h - h), (0, 0)))
            elif h > target_h:
                csi_sample = csi_sample[:target_h, :]

            # Pad or truncate width (time steps)
            if w < target_w:
                csi_sample = np.pad(csi_sample, ((0, 0), (0, target_w - w)))
            elif w > target_w:
                csi_sample = csi_sample[:, :target_w]

            # Guard against non-finite values (e.g., NaN, inf)
            if not np.isfinite(csi_sample).all():
                logger.warning("[Guard] Non-finite values in CSI sample. Skipping.")
                return None

            # Clip extreme values to prevent model instability
            csi_sample = np.clip(csi_sample, -1e3, 1e3)
            csi_sample = csi_sample.reshape(1, *csi_sample.shape)  # Add batch dimension
            csi_sample = self.scaler.fit_transform(csi_sample)  # Normalize the sample

            # Convert to tensor and make a prediction using the ROCKET model
            input_tensor = torch.tensor(csi_sample, dtype=torch.float32)
            pred = int(self.recognizer.predict(input_tensor)[0])  # Get the predicted class index
            area = self.get_area_from_line()  # Get the area (room) from the FIFO data
            self.window_predictions.append((pred, area))  # Add prediction to the sliding window

            # Check if the 3-second window has elapsed
            now = datetime.utcnow()
            if now - self.last_output_time >= self.window_duration:
                if self.window_predictions:
                    # Aggregate predictions by counting occurrences per area-activity pair
                    pred_counts = {}
                    for pred, area in self.window_predictions:
                        key = f"{area}_{self.class_labels[pred]}"
                        pred_counts[key] = pred_counts.get(key, 0) + 1
                    if pred_counts:
                        # Select the most frequent prediction
                        final_pred_key = max(pred_counts, key=pred_counts.get)
                        final_area, final_pose = final_pred_key.split("_", 1)
                        activity = f"{final_area}_{final_pose}"

                        # List areas contributing to the final prediction
                        contributing_areas = [area for pred, area in self.window_predictions
                                           if f"{area}_{self.class_labels[pred]}" == final_pred_key]

                        # Update the output payload
                        self.output_payload["timestamp"] = now.isoformat()
                        self.output_payload["hypothesis"] = activity
                        self.output_payload["rx_sources"] = contributing_areas

                        # Log the activity to Firebase under the specific area
                        self.db.child("activity_logs").child(final_area).push({
                            "timestamp": now.isoformat(),
                            "activity": final_pose,
                            "rx_sources": contributing_areas
                        })
                        logger.info(f"[Firebase] Pushed to activity_logs/{final_area}: {final_pose}")

                        # Check if the system is armed and send an alert for suspicious activities
                        armed = self.db.child("system").get().val().get("armed", True)
                        if armed and final_pose in ['jump', 'walk', 'run']:
                            self.send_alert(activity)

                        # Reset the window and update the last output time
                        self.last_output_time = now
                        self.window_predictions = []

                        logger.info(f"[AGGREGATED] Prediction: {activity} (Areas: {contributing_areas})")
                        return json.dumps(self.output_payload)  # Return the prediction as JSON

            return None

        except Exception as e:
            logger.error(f"[Prediction Error] {e}")
            return None

    def get_next_sample(self) -> Optional[np.ndarray]:
        """Retrieve and preprocess the next CSI sample from the FIFO buffer.
        
        Returns:
            Optional[np.ndarray]: Preprocessed CSI amplitude array (subcarriers x time steps), or None if failed.
        """
        try:
            # Read lines from the FIFO until the expected number of samples is reached
            raw_lines = []
            retries = 0
            while len(raw_lines) < self.expected_samples:
                line = self.fifo.readline()
                if line == "":
                    self.fifo.close()  # Close FIFO if empty
                    self.fifo = None
                    self.ensure_fifo_open()  # Reopen FIFO
                    continue
                if line.startswith("room"):
                    raw_lines.append(line.strip())  # Collect lines starting with "room"
                retries += 1
                if retries > self.expected_samples * 3:
                    break

            # Check if enough lines were read
            if len(raw_lines) < self.expected_samples:
                logger.warning(f"[Sample] Only {len(raw_lines)} lines read, expected {self.expected_samples}")
                return None

            # Parse the raw lines into a DataFrame using predefined column names
            df = pd.read_csv(StringIO("\n".join(raw_lines)), names=CSI_COL_NAMES, on_bad_lines="skip")
            df = df[df["sig_mode"] == 1]  # Filter for valid signal mode

            # Parse the CSI data column into arrays of integers
            parsed = []
            for c in df["data"].copy():
                try:
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore", category=DeprecationWarning)
                        arr = np.fromstring(str(c).strip("[]"), sep=",", dtype=int)
                    if len(arr) > 0 and len(arr) % 2 == 0:  # Ensure even length (real/imaginary pairs)
                        parsed.append(arr)
                except Exception:
                    continue

            if len(parsed) == 0:
                logger.warning("[Sample] No valid parsed data")
                return None

            # Convert parsed data to a NumPy array and remove null subcarriers
            parsed = np.array([x for x in parsed if isinstance(x, np.ndarray) and len(x) % 2 == 0], dtype=object)
            if len(parsed) == 0 or not isinstance(parsed, np.ndarray):
                return None

            parsed = np.delete(parsed.T, NULL_SUBCARRIERS, axis=0).T  # Remove predefined null subcarriers

            # Convert real/imaginary pairs to amplitude values
            cleaned = []
            for i in parsed:
                if not isinstance(i, np.ndarray) or len(i) % 2 != 0:
                    continue
                i = i.astype(float)
                i_amp = np.sqrt(np.square(i[::2]) + np.square(i[1::2]))  # Compute amplitude from real/imaginary
                if not np.isfinite(i_amp).all():
                    continue
                cleaned.append(i_amp)

            if len(cleaned) == 0:
                return None

            # Stack the cleaned amplitudes into a 2D array (subcarriers x time steps)
            try:
                amp = np.stack(cleaned, axis=0)
                logger.debug(f"[Sample] Stacked shape: {amp.shape}")
            except Exception as e:
                logger.warning(f"[Stack Error] {e}")
                return None

            if amp.ndim != 2 or not np.isfinite(amp).all():
                return None

            return amp.T  # Transpose to (subcarriers x time steps)

        except Exception as e:
            logger.error(f"[Sample Error] Failed to parse CSI data: {e}")
            return None

async def handler(websocket, path, har_instance, broadcast_frequency):
    """Handle WebSocket connections, sending predictions at the specified frequency.
    
    Args:
        websocket: WebSocket connection object.
        path: WebSocket path (unused).
        har_instance: CSIHAR instance for making predictions.
        broadcast_frequency (float): Frequency (Hz) to broadcast predictions.
    """
    try:
        while True:
            await asyncio.sleep(1 / broadcast_frequency)  # Delay based on broadcast frequency
            prediction_payload = har_instance.make_prediction()  # Get the latest prediction
            if prediction_payload:
                try:
                    await websocket.send(prediction_payload)  # Send the prediction to the client
                except websockets.exceptions.ConnectionClosed:
                    break  # Exit if the connection is closed
    finally:
        pass

async def main(args):
    """Main coroutine to start the WebSocket server and run the HAR system.
    
    Args:
        args: Command-line arguments (config path, host, port, frequency).
    """
    # Load the configuration from the specified JSON file
    with open(args.config, "r") as f:
        config = json.load(f)

    # Initialize the CSIHAR instance with the loaded config
    har = CSIHAR(config)
    # Start the WebSocket server to handle predictions
    async with websockets.serve(
        lambda websocket, path: handler(websocket, path, har, args.frequency),
        args.host,
        args.port,
    ):
        logger.info(f"[WebSocket Server] Listening on {args.host}:{args.port}")
        await asyncio.Future()  # Run indefinitely until interrupted

if __name__ == "__main__":
    """Entry point for the script, parsing command-line arguments and starting the server."""
    import argparse

    # Define command-line arguments
    parser = argparse.ArgumentParser(description="Realtime HAR via CSI stream & WebSocket")
    parser.add_argument("--config", required=True, type=str, help="Path to config.json")
    parser.add_argument("--host", default="localhost", type=str, help="WebSocket host")
    parser.add_argument("--port", default=9999, type=int, help="WebSocket port")
    parser.add_argument("--frequency", default=2.0, type=float, help="Broadcast frequency in Hz")
    args = parser.parse_args()

    try:
        asyncio.run(main(args))  # Run the main coroutine
    except KeyboardInterrupt:
        pass  # Gracefully exit on keyboard interrupt
