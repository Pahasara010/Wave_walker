#!/usr/bin/env python3

import asyncio  # For handling asynchronous WebSocket communication and animation loop
import pygame  # For creating the graphical visualization with a stickman
import math  # For animating the stickman's limbs using trigonometric functions
import json  # For parsing WebSocket messages containing activity data
import websockets  # For connecting to the WebSocket server to receive activity predictions
import platform  # For checking if running on Emscripten (Pyodide in browser)

# Constants for the visualization window
WIDTH, HEIGHT = 500, 500  # Set window dimensions to 500x500 pixels
WS_SERVER = "ws://127.0.0.1:9999"  # WebSocket server address to receive activity data
FPS = 30  # Frames per second for smooth animation

# Initialize pygame for visualization
pygame.init()  # Initialize Pygame library
screen = pygame.display.set_mode((WIDTH, HEIGHT))  # Create a window of specified size
pygame.display.set_caption("🕴️ CSI Activity Visualizer")  # Set window title with emoji
clock = pygame.time.Clock()  # Create a clock to control frame rate
font = pygame.font.SysFont("Arial", 24)  # Initialize font for rendering action text

# Global variable to store the current detected action
current_action = "idle"  # Default action when no data is received

# Function to draw an animated stickman representing the detected activity
def draw_stickman(center_x, center_y, pose="idle", t=0):
    # Args: center_x (int): X-coordinate of stickman center
    #       center_y (int): Y-coordinate of stickman center
    #       pose (str): Current activity (e.g., walking, jumping)
    #       t (float): Time variable for animation
    screen.fill((240, 240, 240))  # Fill background with a light gray color

    head_radius = 20  # Radius of the stickman's head
    body_length = 60  # Length of the stickman's body
    limb_length = 35  # Length of arms and legs

    # Draw head as a circle
    pygame.draw.circle(screen, (0, 0, 0), (center_x, center_y), head_radius, 2)
    # Draw body as a line from bottom of head to torso end
    body_end = (center_x, center_y + body_length)
    pygame.draw.line(screen, (0, 0, 0), (center_x, center_y + head_radius), body_end, 2)

    # Calculate limb positions based on the pose and animation time
    angle = math.sin(t * 5) * 0.5  # Oscillating angle for smooth animation

    if pose == "walking":  # Animate walking with swinging arms and legs
        leg1 = (center_x - int(limb_length * math.sin(angle)), body_end[1] + int(limb_length * math.cos(angle)))
        leg2 = (center_x + int(limb_length * math.sin(angle)), body_end[1] + int(limb_length * math.cos(angle)))
        arm1 = (center_x - int(limb_length * math.sin(angle)), center_y + 20)
        arm2 = (center_x + int(limb_length * math.sin(angle)), center_y + 20)
    elif pose == "jumping":  # Animate jumping with raised arms and bent legs
        center_y -= 30  # Lift the stickman up to simulate a jump
        leg1 = (center_x - 10, body_end[1])
        leg2 = (center_x + 10, body_end[1])
        arm1 = (center_x - 20, center_y)
        arm2 = (center_x + 20, center_y)
    elif pose == "running":  # Animate running with faster swinging arms and legs
        leg1 = (center_x - int(limb_length * math.sin(t * 8)), body_end[1] + int(limb_length * math.cos(t * 8)))
        leg2 = (center_x + int(limb_length * math.sin(t * 8)), body_end[1] + int(limb_length * math.cos(t * 8)))
        arm1 = (center_x - int(limb_length * math.sin(t * 8)), center_y + 20)
        arm2 = (center_x + int(limb_length * math.sin(t * 8)), center_y + 20)
    elif pose == "empty":  # Minimal pose for 'empty' activity
        leg1 = leg2 = (center_x, body_end[1] + 10)
        arm1 = arm2 = (center_x, center_y + 10)
    else:  # Default to idle pose with straight limbs
        leg1 = (center_x - 10, body_end[1] + limb_length)
        leg2 = (center_x + 10, body_end[1] + limb_length)
        arm1 = (center_x - 20, center_y + 20)
        arm2 = (center_x + 20, center_y + 20)

    # Draw limbs as lines connecting to the body
    pygame.draw.line(screen, (0, 0, 0), body_end, leg1, 2)
    pygame.draw.line(screen, (0, 0, 0), body_end, leg2, 2)
    pygame.draw.line(screen, (0, 0, 0), (center_x, center_y + 10), arm1, 2)
    pygame.draw.line(screen, (0, 0, 0), (center_x, center_y + 10), arm2, 2)

    # Display the current action as text on the screen
    label = font.render(f"Action: {pose.title()}", True, (20, 20, 20))
    screen.blit(label, (20, 20))

# WebSocket client to receive activity predictions
async def listen_ws():
    # Continuously listen for WebSocket messages and update the current action
    global current_action
    while True:
        try:
            async with websockets.connect(WS_SERVER) as websocket:  # Connect to the WebSocket server
                print("✅ Connected to WebSocket")
                while True:
                    message = await websocket.recv()  # Receive message from server
                    data = json.loads(message)  # Parse JSON message
                    index = data["hypothesis"]  # Get the predicted activity index
                    labels = data["classnames"]  # Get the list of possible activity labels
                    current_action = labels[index] if 0 <= index < len(labels) else "unknown"  # Update action
        except Exception as e:
            print(f"[!] WebSocket error: {e}")  # Log any WebSocket connection errors
            current_action = "idle"  # Fallback to idle pose on error
            await asyncio.sleep(2)  # Wait 2 seconds before retrying

# Asynchronous loop to run the Pygame visualization
async def run_visualizer():
    # Animate the stickman based on the current action
    t = 0  # Initialize time variable for animation
    while True:
        t += 0.1  # Increment time for animation
        for event in pygame.event.get():  # Handle Pygame events
            if event.type == pygame.QUIT:  # Check for window close event
                pygame.quit()  # Quit Pygame
                return

        draw_stickman(WIDTH // 2, HEIGHT // 3, pose=current_action, t=t)  # Draw stickman at center
        pygame.display.flip()  # Update the display
        clock.tick(FPS)  # Control frame rate
        await asyncio.sleep(0.01)  # Yield control for a short time

# Main coroutine to run WebSocket listener and visualizer concurrently
async def main():
    # Run the WebSocket listener and visualizer tasks together
    await asyncio.gather(
        listen_ws(),
        run_visualizer()
    )

# Entry point for the script
if platform.system() == "Emscripten":  # Check if running in Pyodide (browser)
    asyncio.ensure_future(main())  # Schedule the main coroutine for Pyodide
else:
    if __name__ == "__main__":
        try:
            asyncio.run(main())  # Run the main coroutine for desktop Python
        except KeyboardInterrupt:
            print("👋 Exiting visualizer")  # Log exit on user interrupt
            pygame.quit()  # Clean up Pygame resources
